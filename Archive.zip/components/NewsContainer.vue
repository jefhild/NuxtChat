<template>
  <HomeRecent />
  <HomeMale />
  <HomeFemale />
  <HomeMostPopular />
  <!-- <HomeOther /> -->
</template>
