<template>
  <v-row>
    <v-col cols="12" md="6">
      <FreeChatAiProfiles />
    </v-col>
    <v-col cols="12" md="6"> 
      <FreeChatRealProfiles />
    </v-col>
  </v-row>
</template>
