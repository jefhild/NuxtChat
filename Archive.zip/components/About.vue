<template>
  <v-container>
    <v-row
      ><v-col>
        <h1>About Us</h1>
      </v-col></v-row
    >

    <v-row
      ><v-col>
        <h4>Hi! Welcome to Imchatty.com</h4>
        <p class="text-body-2">
          Welcome to Imchatty, a free chat site where you can connect with
          others anonymously. Our mission is to provide a safe and free platform
          for people to chat and share their thoughts without the need for
          extensive personal information. At Imchatty, we believe in the power
          of conversation and the importance of privacy.
        </p></v-col
      ></v-row
    >

    <v-row
      ><v-col>
        <h4>Who We Are</h4>
        <p class="text-body-2">
          Imchatty is a project by
          <a href="https://oliverwjones..com">Oliver W. Jones</a>, a seasoned
          player in the IT consulting industry. We created this site to delve
          deeper into real-time database and presence technology, AI chatbots
          and LLM's. We're using Imchatty as a dynamic sandbox for testing and
          development. We'd love to see how far we can push this technology and
          if we can build something useful. You'll find the Open Source code for
          this site <a href="https://github.com/jefhild/NuxtChat">here</a>.
        </p></v-col
      ></v-row
    >

    <v-row
      ><v-col>
        <h4>Our Mission and Vision</h4>
        <p class="text-body-2">
          Our mission is simple: to offer a free and secure chat platform
          supported by advertising, which will cover the infrastructure costs.
          Our vision is to continually add services and features, evolving
          Imchatty into a robust and valuable tool for our users. We aspire to
          create a space where users can enjoy seamless communication while
          feeling safe and respected.
        </p></v-col
      ></v-row
    >

    <v-row
      ><v-col>
        <h4>Our Unique Approach</h4>
        <p class="text-body-2">
          What sets Imchatty apart is our commitment to providing a truly free
          service without compromising on user safety. We understand the
          importance of privacy, and our anonymous registration ensures that
          your personal information remains confidential. Additionally, Imchatty
          serves as a testing ground for innovative technologies, helping us
          stay at the forefront of IT advancements.
        </p></v-col
      ></v-row
    >

    <v-row
      ><v-col>
        <h4>Building a Community</h4>
        <p class="text-body-2">
          Our goal is not just to offer a chat service but to build a community.
          We encourage our users to provide feedback and share their experiences
          to help us improve and expand the platform. By working together, we
          hope to create a service that meets the needs of our users and adapts
          to their evolving preferences.
        </p></v-col
      ></v-row
    >

    <v-row
      ><v-col>
        <h4>Looking Ahead</h4>
        <p class="text-body-2">
          As we continue to grow, our focus remains on maintaining a free and
          secure platform while exploring new features and improvements. We are
          excited about the future of Imchatty and are committed to making it a
          valuable resource for our users.
        </p></v-col
      ></v-row
    >

    <v-row
      ><v-col>
        <h4>Join Us</h4>
        <p class="text-body-2">
          We invite you to join Imchatty and be a part of our journey. Whether
          you’re looking for a place to chat, share ideas, or simply meet new
          people, Imchatty is here for you. Together, we can create a dynamic
          and fun community.
        </p></v-col
      ></v-row
    >
  </v-container>
</template>
