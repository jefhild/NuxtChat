<template>
  <v-footer>
    <v-row>
      <v-col class="text-center">
        <v-card>
          <v-card-text>
            <!-- Footer Content -->
            &copy; 2024 Oliver W. Jones
            <NuxtLink to="/about">About Us</NuxtLink> |
            <NuxtLink to="/terms">Terms Of Service</NuxtLink> |
            <NuxtLink to="/privacy">Privacy Policy</NuxtLink> |
            <!-- <NuxtLink to="/cookies">Cookies</NuxtLink> | -->
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-footer>
</template>
