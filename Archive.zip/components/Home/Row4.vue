<template>
  <v-card>
    <v-card-text>
      <v-row class="rowbg colstyle" justify="center" align="center"
        ><v-col class="text-center"
          >Free Online Chat. Meet a friend, a lover, or just a chat
          buddy.</v-col
        ><v-col class="text-center d-none d-md-flex"
          >Try it out anonymously. Sign in to get all the free features.</v-col
        ></v-row
      >
    </v-card-text>
  </v-card>
</template>

<script lang="ts" setup></script>

<style>
.rowbg {
  background-color: #fdfaf6;
}

.colstyle {
  font-family: "poppins", sans-serif;
  font-size: 1rem;
  font-weight: 400;
}
</style>
