<template>
  <v-container fluid>
    <HomeRow1 />
    <FreeChat />
  </v-container>
</template>
<script setup>
useHead(() => ({
  link: [
    {
      rel: "canonical",
      href: "https://imchatty.com/freechat",
    },
  ],
  title: "Look who's chatting for free",
}));
</script>