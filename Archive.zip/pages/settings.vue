<template>
  <v-container fluid>
    <HomeRow1 />
    <v-row>
      <v-col>
        <SettingsContainer/>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
</script>