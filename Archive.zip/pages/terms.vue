<template>
  <v-container>
    <v-row>
      <v-col>
        <h1>Terms and Conditions</h1>
        <!-- <p class="text-body-2">
          These are the terms and conditions of our website.
        </p> -->
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Welcome to the Imchatty website. Please review these Terms of Service
          (“Terms”), which govern your use of the website and services provided
          by it.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          The website imchatty.com (the “Site”) facilitates real-time
          interactions in a secure environment that protects user privacy, (the
          “Service”). The Terms describe the conditions under which this Service
          is being made available to you, and your access to and use of the Site
          and the Service. Read the Terms carefully. By using the Service, you
          will be deemed to have accepted it. If you do not accept the Terms,
          you may not use this Service. By accessing the Site, you agree to
          abide by these Terms of Service ("Terms"), which govern your use of
          the Website, which is further subject to our Privacy Policy and safety
          guidelines.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          In this document, “we” or “us” means imchatty.com and its owners,
          managers, officers, employees, partners, agents, representatives,
          affiliates, contractors, service providers, and/or designees; “both of
          us” means both you and us; “Terms of Service” or “Terms” means these
          Terms of Service and documents incorporated by reference; “Our
          Materials” means information, data, text, software, music, sound,
          photographs, graphics, video, messages or other materials that we may
          make available through the Service; “Service” means the service we
          provide you at the Site; “Site” means www.imchatty.com and any other
          website designated by us as being subject to the Terms; “you” means
          the person or company using the Services; and “Content” means
          information, data, text, software, music, sound, photographs,
          graphics, video, messages, images or other materials made available or
          accessible through the Service by you or other users of the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>THE SERVICE</h4>
        <p class="text-body-2">
          We currently are in beta and offer a simple chat feature for engaging
          conversations. We hope to be offering other services soon, and will be
          updating our policy and terms document as these services become
          available.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>ACQUISITION OF USE RIGHTS</h4>
        <p class="text-body-2">
          You acquire rights to use the Service subject to these Terms by
          enrolling in the Service at imchatty.com.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>USE OF SERVICE</h4>
        <p class="text-body-2">
          Except as set forth in “Other agreements”, below, we authorize you to
          use the Service only for your own personal, non-commercial purposes.
          Use of the Service for any public or commercial purpose (including,
          without limitation, use of the Service for the benefit of third
          parties) is strictly prohibited. If you make copies of any of Our
          Materials, you must retain on any such copies all copyright and other
          proprietary notices contained in Our Materials as provided by us. You
          may not modify, publicly display, publicly perform, or distribute Our
          Materials. As between you and us, we own the Service, Site and Our
          Materials. The Service, Site and Our Materials are protected under
          United States and international copyright laws. Any unauthorized use
          of the Service, Site or Our Materials may violate copyright,
          trademark, and other laws.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>ELIGIBILITY</h4>
        <p class="text-body-2">
          Conduct and Prohibited Uses. You must be of at least eighteen (18)
          years of age to use the services on this Website. You agree and
          warrant that none of Your Content shall be of a pornographic
          (including but not limited to child pornography), violent,
          discriminatory, unlawful, hateful, obscene, lewd, nude, partially nude
          or sexually suggestive nature, drug or terrorism-related, harmful,
          deceptive, extremely profane, racist, defamatory, abusive, threatening
          or otherwise objectionable in any manner (together “Objectionable
          Content”).
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          You represent and warrant that you shall not solicit personal
          information from or exploit in a sexual or violent manner anyone under
          the age of eighteen (18). You also represent and warrant that none of
          Your Content infringes the rights of any other third party. Imchatty
          disclaims any duty to monitor the nature of Your Content, and
          disclaims any liability or responsibility for any of Your Content.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          You also represent and warrant that you will not “stalk” or otherwise
          harass any other user of this Website, impersonate other people or
          organizations, provide false, misleading or inaccurate information to
          Imchatty, interfere with our servers or software, attempt to access
          any restricted area on the Website, post harmful or disruptive
          html/javascript, upload or transmit files containing viruses or other
          objects which may damage other devices, access the Website through
          bots, agents, scraping, automated devices or intelligent search, or
          use the Website for spam purposes, unauthorised advertising or
          promotional purposes or to conduct surveys of any nature (together,
          “Prohibited Uses”).
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Modifications. We reserve the right to modify or replace these Terms
          at any time. Any updated Terms will be available at this link. These
          Terms may be updated, reviewed, or amended from time to time, at our
          sole discretion. Material changes in these terms might or might not be
          communicated on our home page. You should periodically refer to any
          changes made to these Terms. Continued use of the Website, or use of
          any of the services or purchase of any product, will thereafter
          constitute your deemed acceptance of the revised Terms., Conduct and
          Prohibited Uses. You must be of at least eighteen (18) years of age to
          use the services on this Website. You agree and warrant that none of
          Your Content shall be of a pornographic (including but not limited to
          child pornography), violent, discriminatory, unlawful, hateful,
          obscene, lewd, nude, partially nude or sexually suggestive nature,
          drug or terrorism-related, harmful, deceptive, extremely profane,
          racist, defamatory, abusive, threatening or otherwise objectionable in
          any manner (together “Objectionable Content”).
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>YOUR REGISTRATION OBLIGATIONS</h4>
        <p class="text-body-2">
          Certain portions of the Service may require registration and provision
          by you of certain information regarding yourself to us. If you
          register, you represent that you are at least 18 years old and are not
          a person barred from receiving services under the laws of the United
          States, European Union or other applicable jurisdiction. You must: (a)
          provide true, accurate, current and complete information about
          yourself as prompted by the Service's registration form (such
          information being the “Registration Data”) and (b) maintain and
          promptly update the Registration Data to keep it true, accurate,
          current and complete. If you provide any information that is untrue,
          inaccurate, not current or incomplete, or we have reasonable grounds
          to suspect that such information is untrue, inaccurate, not current or
          incomplete, we have the right to suspend or terminate your account and
          refuse any and all current or future use of the Service (or any
          portion thereof).
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>MEMBER ACCOUNT, PASSWORD AND SECURITY</h4>
        <p class="text-body-2">
          You may receive or create a password and account designation upon
          completing the Service’s registration process. You are responsible for
          maintaining the confidentiality of the password and account
          designation, and are fully responsible for all activities that occur
          under your password or account. You must (a) immediately notify us of
          any unauthorized use of your password or account or any other breach
          of security, and (b) ensure that you exit from your account at the end
          of each session. We cannot and will not be liable for any loss or
          damage arising from your failure to comply with this Section.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>PRIVACY POLICY; USE OF PERSONALLY IDENTIFIABLE DATA</h4>
        <p class="text-body-2">
          Registration Data and certain other information about you is subject
          to our Privacy Policy. For more information, see our full privacy
          policy. By using the Service you consent to the collection and use (as
          set forth in the Privacy Policy) of this information, including the
          transfer of this information to the United States and/or other
          countries for storage, processing, and use by us and our affiliates.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col class="ml-5">
        <h5>General Data Protection Regulation (GDPR) Compliance</h5>
        <p class="text-body-2">
          If you are a resident of or are located in the European Union or
          European Economic Area (“EEA”), you may also have certain rights under
          the General Data Protection Regulation (“GDPR”). Personal information
          (“Personal Data”) you provide on imchatty.com websites or through its
          products is only collected with your consent, and is subject to the
          terms of the Company’s Privacy Policy, which may be found here.
          Contact help@imchatty.com if you have concerns regarding your Personal
          Data, or wish to exercise any of your rights under the GDPR.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>BILLING; TAXES</h4>
        <p class="text-body-2">
          Currently imchatty.com is a service without consumer tax implications.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>MEMBER CONDUCT</h4>
        <p class="text-body-2">
          You understand that all Content, whether publicly posted or privately
          transmitted, are the sole responsibility of the person from whom such
          Content originated. This means that you, and not us, are entirely
          responsible for all Content that you upload, post, email, transmit or
          otherwise make available or access via the Service. We do not control
          the Content posted or accessed via the Service and, as such, do not
          guarantee the accuracy, integrity or quality of such Content. You
          understand that by using the Service, you may be exposed to Content
          that is offensive, indecent or objectionable. Under no circumstances
          will we be liable in any way for any Content, including, but not
          limited to, for any errors or omissions in any Content, or for any
          loss or damage of any kind incurred as a result of the use of any
          Content posted, emailed, transmitted or otherwise made available or
          accessed via the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Any use of the Service is subject to our code of conduct.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          We may or may not pre-screen Content; however, we and our designees
          shall have the right (but not the obligation) in our sole discretion
          to pre-screen, refuse, or move any Content or block any sites that are
          available or accessible via the Service. Without limiting the
          foregoing, we and our designees shall have the right to remove or
          block access to any Content that violates the Terms or is otherwise
          objectionable. You must evaluate, and bear all risks associated with,
          the use of any Content, including any reliance on the accuracy,
          completeness, or usefulness of such Content.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          We may access, preserve, and disclose your account information and
          Content if required to do so by law or in a good faith belief that
          such access preservation or disclosure is reasonably necessary to: (a)
          comply with legal process; (b) enforce the Terms; (c) respond to
          claims that any Content violates the rights of third-parties; (d)
          respond to your requests for customer service; or (e) protect our (or
          our users or the public's) rights, property, or personal safety.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          The technical processing and transmission of the Service, including
          your Content, may involve (a) transmissions over various networks; and
          (b) changes to conform and adapt to technical requirements of
          connecting networks or devices.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          The Service and software embodied within the Service may include
          security components that permit digital materials to be protected, and
          use of these materials is subject to usage rules set by us and/or
          content providers who provide content to the Service. You may not
          attempt to override or circumvent any of the usage rules embedded into
          the Service. Any unauthorized reproduction, publication, further
          distribution or public exhibition of the materials provided on the
          Service, in whole or in part, is strictly prohibited.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>
          OWNERSHIP AND USE OF CONTENT SUBMITTED OR MADE AVAILABLE FOR INCLUSION
          ON THE SERVICE
        </h4>
        <p class="text-body-2">
          We do not claim ownership of Content you submit or make available for
          inclusion on the Service. However, with respect to Content you submit
          or make available for inclusion on areas of the Service accessible to
          other members, the license to use, distribute, reproduce, modify,
          adapt, publicly perform and publicly display such Content on the
          Service solely for the purposes of providing and promoting the members
          to which such Content was submitted or made available. This license
          exists only for as long as you elect to continue to include such
          Content on the Service and will terminate at the time you remove or we
          remove such Content from the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          You may voluntarily provide (in connection with use of the Service,
          use of our products or otherwise) suggestions, comments or other
          feedback to us with respect to items or information provided by us on
          the Service or otherwise. We are not required to hold such feedback in
          confidence, and such feedback may be used by us for any purpose
          without obligation of any kind; provided, that we will not disclose
          the source of specific feedback without your consent; and nothing in
          the Terms restricts the use by you of such feedback or ideas that you
          provide to us.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Any content, including but not limited to photographs, pictures,
          images, and video clips which you upload onto the Website, or share
          with other users of this Website (“Your Content”) is owned by you.
          imchatty does not claim any ownership of Your Content. You grant
          imchatty a non-exclusive, royalty-free, perpetual, sub-licensable,
          worldwide license to use Your Content, in accordance with our
          Website’s Privacy Policy. You can choose to share Your Content with
          other users of our Website while chatting. You represent and warrant
          that you are the owner of Your Content, and are not violating any
          third-party rights by posting or sharing Your Content on our Website.
          We do not necessarily endorse Your Content, and have no obligation to
          monitor, edit, remove or prescreen Your Content. You are solely liable
          for any of Your Content posted or shared on this Website. You are also
          solely responsible for your interaction with other users on this
          Website, both online and offline, and imchatty is not liable for the
          conduct of any of its users. In case you think that some user of
          imchatty itself is infringing your intellectual property rights
          through our Website, you can promptly contact us, and we will reserve
          the right to delete content alleged to be infringing, and even
          terminate the accounts of repeat offenders.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>INDEMNITY</h4>
        <p class="text-body-2">
          You hereby indemnify and hold us and our subsidiaries, affiliates,
          officers, agents, co-branders or other partners, and employees,
          consultant and agents harmless from any claim or demand (including
          reimbursing us any reasonable attorneys' fees incurred by us in the
          defense of any such claim or demand), made by any third party due to
          or arising out of Content you submit, post, transmit or make available
          through the Service, your use of the Service, your connection to the
          Service, your violation of the Terms, or your violation of any rights
          of another. We retain the right to retain counsel of our choosing in
          our sole discretion. Furthermore, you must cooperate in good faith to
          assist us in our defense and any settlement negotiations related
          thereto, and to reimburse us for reasonable settlement amounts, if
          any.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>GENERAL PRACTICES REGARDING USE AND STORAGE</h4>
        <p class="text-body-2">
          You acknowledge that we may establish general practices and limits
          concerning use of the Service, including without limitation the
          maximum number of days that uploaded Content will be retained by the
          Service, the maximum number and size of postings that may be made
          through an account on the Service, and the maximum number of times
          (and the maximum duration for which) you may access the Service in a
          given period of time. We have no responsibility or liability for the
          deletion or failure to store any posting and other communications or
          other Content maintained or transmitted by the Service. We may modify
          these general practices and limits from time to time.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>MODIFICATIONS TO SERVICE</h4>
        <p class="text-body-2">
          We may at any time and from time to time to modify or discontinue,
          temporarily or permanently, the Service (or any part thereof) with or
          without notice. We shall not be liable to you or to any third party
          for any modification, suspension or discontinuance of the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>TERMINATION</h4>
        <p class="text-body-2">
          We may, under certain circumstances and without prior notice,
          immediately terminate your account and access to the Service. Cause
          for such termination shall include, but not be limited to, (a)
          breaches or violations of the Terms or other incorporated agreements
          or guidelines, (b) requests by law enforcement or other government
          agencies, (c) a request by you (self-initiated account deletions), (d)
          discontinuance or material modification to the Service (or any part
          thereof), (e) unexpected technical or security issues or problems, (f)
          extended periods of inactivity, (g) you have engaged in fraudulent or
          illegal activities, and/or (h) nonpayment of any fees owed by you in
          connection with the Services. Termination of your account includes (a)
          removal of access to all offerings within the Service, (b) deletion of
          your password and all related information, files and content
          associated with or inside your account (or any part thereof), and (c)
          barring further use of the Service. Further, all terminations for
          cause shall be made in our sole discretion and we shall not be liable
          to you or any third-party for any termination of your account, any
          associated email address, or access to the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>DEALINGS WITH THIRD PARTIES</h4>
        <p class="text-body-2">
          The Service might enable you to access other web sites or resources.
          Because we have no control over such sites and resources, we are not
          responsible for the availability of such external sites or resources,
          and we do not endorse and are not responsible or liable for any
          Content, products, or other materials on or available from such sites
          or resources. We are not responsible or liable, directly or
          indirectly, for any damage or loss caused or alleged to be caused by
          or in connection with use of or reliance on any such Content or
          services available on or through any such site or resource. We may or
          may not pre-screen other websites or resources; however, we and our
          designees shall have the right (but not the obligation) in our sole
          discretion to pre-screen, refuse or block access to any web sites or
          other resources that violate the Terms or are otherwise objectionable.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>OUR PROPRIETARY RIGHTS</h4>
        <p class="text-body-2">
          The Service and any necessary software used in connection with the
          Service (“Software”) contain proprietary and confidential information
          that is protected by applicable intellectual property and other laws.
          You may not access the Service by any means other than through the
          interface that is provided by us for use in accessing the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          In general, the Service is provided in a manner which does not result
          in your downloading or using any of our Software. In the event that we
          do, however, provide you with Software (such as a plug-in or similar
          item), we grant you a personal, non-transferable and non-exclusive
          right and license to use the object code of the Software on a single
          computer in connection with your access to the Service; provided that
          you do not (and do not allow any third party to) copy, modify, create
          a derivative work of, reverse engineer, reverse assemble or otherwise
          attempt to discover any source code, sell, assign, sublicense, grant a
          security interest in or otherwise transfer any right in the Software.
          You may not modify the Software in any manner or form, or to use
          modified versions of the Software, including (without limitation) for
          the purpose of obtaining unauthorized access to the Service. You may
          not rent, lease, loan, sell, distribute or create derivative works
          based on the Software, in whole or in part.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          You may not reproduce, duplicate, copy, sell, trade, resell or exploit
          for any commercial purposes, any portion of the Service (including
          your account name), use of the Service, or access to the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>DISCLAIMER OF WARRANTIES</h4>
        <p class="text-body-2">
          <v-list>
            <v-list-item>
              YOUR USE OF THE SERVICE IS AT YOUR SOLE RISK. THE SERVICE IS
              PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS. WE EXPRESSLY
              DISCLAIM ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED,
              INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
              MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
              NON-INFRINGEMENT."
            </v-list-item>

            <v-list-item
              >WE MAKE NO WARRANTY THAT (i) THE SERVICE WILL MEET YOUR
              REQUIREMENTS, (ii) THE SERVICE WILL BE UNINTERRUPTED, TIMELY,
              SECURE, OR ERROR-FREE, (iii) THE RESULTS THAT MAY BE OBTAINED FROM
              THE USE OF THE SERVICE WILL BE ACCURATE OR RELIABLE, (iv) THE
              QUALITY OF ANY PRODUCTS, SERVICES, INFORMATION, OR OTHER MATERIAL
              PURCHASED OR OBTAINED BY YOU THROUGH THE SERVICE WILL MEET YOUR
              EXPECTATIONS, AND (v) ANY ERRORS IN THE SOFTWARE WILL BE
              CORRECTED.</v-list-item
            >
            <v-list-item
              >ANY MATERIAL DOWNLOADED OR OTHERWISE OBTAINED THROUGH THE USE OF
              THE SERVICE IS DONE AT YOUR OWN DISCRETION AND RISK AND THAT YOU
              WILL BE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM
              OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY SUCH
              MATERIAL.</v-list-item
            >
            <v-list-item
              >NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY
              YOU FROM US OR THROUGH OR FROM THE SERVICE SHALL CREATE ANY
              WARRANTY NOT EXPRESSLY STATED IN THE TERMS.</v-list-item
            >
          </v-list>
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>LIMITATION OF LIABILITY</h4>
        <p class="text-body-2">
          WE SHALL NOT BE LIABLE TO YOU FOR ANY DIRECT, INDIRECT, INCIDENTAL,
          SPECIAL, CONSEQUENTIAL OR EXEMPLARY DAMAGES, INCLUDING BUT NOT LIMITED
          TO, DAMAGES FOR LOSS OF PROFITS, GOODWILL, USE, DATA OR OTHER
          INTANGIBLE LOSSES (EVEN IF WE HAVE BEEN ADVISED OF THE POSSIBILITY OF
          SUCH DAMAGES), RESULTING FROM: (i) THE USE OR THE INABILITY TO USE THE
          SERVICE; (ii) THE COST OF PROCUREMENT OF SUBSTITUTE GOODS AND SERVICES
          RESULTING FROM ANY GOODS, DATA, INFORMATION OR SERVICES PURCHASED OR
          OBTAINED OR MESSAGES RECEIVED OR TRANSACTIONS ENTERED INTO THROUGH OR
          FROM THE SERVICE; (iii) UNAUTHORIZED ACCESS TO OR ALTERATION OF YOUR
          TRANSMISSIONS OR DATA; (iv) STATEMENTS OR CONDUCT OF ANY THIRD PARTY
          ON THE SERVICE; OR (v) ANY OTHER MATTER RELATING TO THE SERVICE.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>EXCLUSIONS AND LIMITATIONS</h4>
        <p class="text-body-2">
          SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF CERTAIN WARRANTIES OR
          THE LIMITATION OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR
          CONSEQUENTIAL DAMAGES. ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS OF
          MAY NOT APPLY TO YOU.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>GENERAL INFORMATION</h4>
        <p class="text-body-2">
          Entire Agreement. The Terms constitute the entire agreement between
          both of us and governs your use of the Service, superseding any prior
          agreements between both of us with respect to the Service. You also
          may be subject to additional terms and conditions that may apply when
          you use or purchase certain other services, affiliate services,
          third-party content, or third-party software.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Choice of Law and Forum. The Terms and the relationship between both
          of us shall be exclusively governed by the laws of the European Union
          without regard to its conflict of law provisions. Your exclusive forum
          for bringing any claim or cause of action against us is the courts
          located in the City of Paris, France. You hereby accept and submit to
          the personal and exclusive jurisdiction of such courts in any
          proceeding or action. With respect to any such proceeding or action
          brought in such courts, you hereby irrevocably waive, to the fullest
          extent permitted by law: (a) any objection you may have now or in the
          future to such jurisdiction or venue, and (b) any claim that such
          action or proceeding has been brought in an inconvenient form. Nothing
          limits our right to commence and prosecute any legal or equitable
          action or proceeding before any court of competent jurisdiction to
          obtain injunctive or any other form of relief. Regardless of any
          statute or law to the contrary, any claim or cause of action arising
          out of or related to use of the Service or the Terms must be filed
          within ninety (90) days (or, if different, the minimum amount of time
          permitted by law) after such claim or cause of action arose or be
          forever barred.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Arbitration. Notwithstanding anything herein, if we elect in our sole
          discretion to resolve any claim through arbitration, you must
          cooperate fully with and be bound by such arbitration, without further
          recourse of any kind. The European Court of Arbitration (ECA) shall
          preside over such arbitration. Such arbitration shall be exclusively
          governed by the laws of the European Union without regard to its
          conflict of law provisions. All proceedings shall take place in the
          City of Paris. If there is a conflict between the rules of the ECA and
          any provision of the Terms, the Terms shall govern. You are
          responsible for all costs that you incur in the arbitration, including
          without limitation, expert witnesses or attorneys. The reasonable
          filing fees and arbitrator’s costs and expenses shall be advanced by
          us. However, if the arbitration is decided in our favor, you must
          reimburse us for all of our fees, costs, and expenses related to the
          arbitration, including without limitation, all fees, costs, and
          expenses related to filing, arbitrators, expert witnesses, attorneys,
          and other third parties.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Waiver and Severability of Terms. Our failure to exercise or enforce
          any right or provision of the Terms shall not constitute a waiver of
          such right or provision. If any provision of the Terms is found by a
          court of competent jurisdiction to be invalid, the parties
          nevertheless agree that the court should endeavor to give effect to
          the parties' intentions as reflected in the provision, and the other
          provisions of the Terms remain in full force and effect.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          No Third Party Beneficiaries. Except as otherwise expressly provided
          in the Terms, there shall be no third party beneficiaries to the
          Terms.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Restrictions on Assignment. These Terms and all of the rights,
          interest or obligations hereunder may be not assigned, directly or
          indirectly, including, without limitation, by operation of law, by
          either of us, without the prior written consent of the non-assigning
          party, not to be unreasonably withheld, delayed or conditioned;
          provided, however, either party may assign the Terms without any such
          requirement of consent, in whole or in part to any affiliate,
          subsidiary or successor in interest in the event of a merger,
          consolidation, acquisition, reorganization, change in control or
          otherwise, provided that: (i) the assigning and acquiring entity
          notify the non-assigning party at the time of such assignment and the
          acquiring entity agrees in writing to be bound by the Terms, and (ii)
          the acquiring entity is no a competitor of the non-acquiring entity.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Statute of Limitations. Regardless of any statute or law to the
          contrary, any claim or cause of action arising out of or related to
          use of the Service or the Terms must be filed within one (1) year
          after such claim or cause of action arose or be forever barred.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          The section titles in the Terms are for convenience only and have no
          legal or contractual effect.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>ACCEPTING THE TERMS</h4>
        <p class="text-body-2">
          Agreement to Terms. In order to use the Service, you must first agree
          to the Terms. You may not use the Service if you do not accept the
          Terms. You can accept the Terms by executing by clicking to accept or
          agree to the Terms, where this option is made available to you by us
          in the user interface for the Service, or by actually using the
          Service. You agree that we will treat your use of the Service as
          acceptance of the Terms from that point onwards.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Eligibility to Use the Service. You may not use the Service and may
          not accept the Terms if (a) you are not of legal age (the laws of the
          jurisdiction of which you are a resident or from which you use the
          Service) to form a binding contract with us, or (b) you are a person
          barred from using the Service under the laws of the EU, United States
          or other countries including the country in which you are resident or
          from which you use the Service.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Representation of Eligibility. In any of the above cases, you
          represent that you satisfy all of the above eligibility conditions. If
          you do not satisfy the above conditions, or if you do not agree with
          the Terms, you may not use the Service or any portion thereof; in that
          case we may also terminate the Terms and your use of the Service
          immediately without liability to you.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <p class="text-body-2">
          Acceptance by Electronic Submissions. You acknowledge that your
          electronic submissions constitute your agreement and intent to be
          bound by the Terms. Pursuant to any applicable statutes, regulations,
          rules, ordinances or other laws, you hereby agree to the use of
          electronic signatures, contracts, orders and other records and to
          electronic delivery of notices, policies and records of transactions
          initiated or completed through the Service. Further, you hereby waive
          any rights or requirements under any statutes, regulations, rules,
          ordinances or other laws in any jurisdiction which require an original
          signature or delivery or retention of non-electronic records.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <h4>AMENDMENT AND UPDATING OF THE TERMS.</h4>
        <p class="text-body-2">
          We may desire to make changes to these Terms from time to time to
          update it, for example to add references to different products or
          services. We may specify amended or updated terms that apply to the
          use of Service after the effective date of such amendment or update,
          and we will make a new copy of these Terms available to you and may
          require you to accept it as a condition to the continued provision of
          the Service to you. In addition, the continued use of the Service
          after receipt of such amended Terms shall constitute your agreement to
          such Terms.
        </p>
      </v-col>
    </v-row>
  </v-container>
</template>
